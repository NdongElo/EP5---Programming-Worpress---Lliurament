<?php 
/*
Plugin Name: NDONGELO  debug
Description:Append ?debug=1 to display debug info if you are an admin
Version: 1.0
License: GPLv2
*/

add_action('init', 'ndong_debug_check');

function ndong_debug_check(){
    if(isset($_GET['debug']) && current_user_can('manage_options')){
       if(!defined('SAVEQUERIES')){
           define('SAVEQUERIES', true);
       } 
       add_action('wp_footer', 'ndong_debug_output');
    }
}

function ndong_debug_output() {
    global $wpdb;
    echo "<pre>";
    print_r($wpdb->queries);
    echo "</pre>";
}
?>