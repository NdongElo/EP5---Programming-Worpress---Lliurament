<?php

/**
 * Plugin Name: Hook Test
 * Description: A simple plugin to test hooks
 */
add_action( 'wp_insert_post', 'email_post_author', 10, 3 );
function email_post_author( $post_id, $post, $update ) {
  $email = 'aureliondongelo@gmail.com';
  $subject = 'New Post Published';
  $message = 'A new post was published, use this link to view it: ' . get_permalink( $post->ID );
  wp_mail( $email, $subject, $message );
}
/** parte dos del ejercicio1 */
add_filter( 'login_errors', 'modify_login_errors' );
function modify_login_errors() {
    return 'prueba otra vez, try again';
}

