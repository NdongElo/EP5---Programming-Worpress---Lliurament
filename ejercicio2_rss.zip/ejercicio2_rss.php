<?php 
/*
Plugin Name: NDONGELO RSS Widget
Description: A widget plugin to retrieve
Version: 1.0
License: GPLv2
*/

add_action('wp_dashboard_setup', 'ndong_rss_widget');

function ndong_rss_widget() {
    //create a custom dashboard widget
    wp_add_dashboard_widget('dashboard_custom_feed', 'RSS feed',
    'ndong_rss_display', 'ndong_rss_setup');
}

function ndong_rss_setup() {
    
    //check if option is set before saving
    if(isset($_POST['ndong_rss_feed'])) {
        //retrieve the option value from the form
        $ndong_rss_feed = esc_url_raw($_POST['ndong_rss_feed']);
        //save the value as an option
        update_option('ndong_rss_widget', $ndong_rss_feed);
    }
    
    //load the saved feed if it exists
    $ndong_rss_feed = get_option('ndong_rss_widget');
    
?>
    <label for="feed">
        RSS feed URL: <input type="text" name="ndong_rss_feed"
        id="ndong_rss_feed" 
        value="<?php echo esc_url($ndong_rss_feed); ?>"
        size="50" />
    </label>
    
<?php
    
}

function ndong_rss_display() {
    //load our widget option
    $ndong_option = get_option('ndong_rss_widget');
    //if option is empty, set a default
    $default_feed = 'http://orboan.com/category/Java/feed';
    $ndong_rss_feed = ($ndong_option) ? $ndong_option : $default_feed;
    
    //retrieve the RSS feed and display it
    echo '<div class="rss-widget">';
    wp_widget_rss_output( array(
        'url' => $ndong_rss_feed,
        'title' => 'RSS feed news',
        'items' => 2,
        'show_summary' => 1,
        'show_author' => 0,
        'show_date' => 1
        ));
    echo '</div>';
}
?>