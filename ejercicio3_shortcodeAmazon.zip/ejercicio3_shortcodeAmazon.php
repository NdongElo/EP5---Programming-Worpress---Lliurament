<?php 
/*
Plugin Name: NDONGELO Shorcodes Amazon
Description: A widget plugin to retrieve
Version: 1.0
License: GPLv2
*/

add_shortcode('amazon', 'ndong_amazon');

//Callback function for the [amazon] shortcode
function ndong_amazon($attr, $content) {
    //Get ASIN (Amazon Standard Identification Number)
    if(isset($attr['asin'])){
        //preg_replace — Perform a regular expression search and replace
        //'/[^\d]/' stands for all non numerical characters
        $asin = preg_replace('/[^\d]/', '', $attr['asin']);
    }
    
    //Sanitize content, or set default
    if(!empty($content)) {
        $content = esc_html($content);
    } 
    
    return "<a href='https://www.amazon.co.uk/dp/$asin' target='_blank'>$content</a>";
}